<footer>
			<div id="footer">
				<div class="container">
					<div class="row row-bottom-padded-md">
						
						
						
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-youtube"></i></a>
							</p>
							<p>Copyright 2022  . Wonderful Malang.<br>All Right Reserved</a></p>
						</div>
					</div>
				</div>
			</div>
		</footer>