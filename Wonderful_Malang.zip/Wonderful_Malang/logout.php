<?php
session_start();
session_destroy();
header("location:http://localhost/Wonderful_Malang/index.php");
?>